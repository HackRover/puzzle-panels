#ifndef Boolean_cpp
#define Boolean_cpp

#import "Boolean.h"
#include "Arduino.h"

bool Boolean::OR(bool input1, bool input2)
{
    return input1 || input2;
}//close OR

bool Boolean::AND(bool input1, bool input2)
{
    return input1 && input2;
}//close AND

bool Boolean::NOT(bool input)
{
    return !input;
}//close NOT

bool Boolean::XOR(bool input1, bool input2)
{
    return input1 ^ input2;
}//close XOR

bool Boolean::NOR(bool input1, bool input2)
{
    return !(input1 || input2);
}//close NOR

bool Boolean::XNOR(bool input1, bool input2)
{
    return !(input1 ^ input2);
}//close XNOR

bool Boolean::NAND(bool input1, bool input2)
{
    return !(input1 && input2);
}//close NAND
#endif //Boolean_cpp