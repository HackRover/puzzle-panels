#ifndef Boolean_h
#define Boolean_h

#include "Arduino.h"

class Boolean
{
public:
    static bool OR(bool input1, bool input2);
    static bool AND(bool input1, bool input2);
    static bool NOT(bool input);
    static bool XOR(bool input1, bool input2);
    static bool NOR(bool input1, bool input2);
    static bool XNOR(bool input1, bool input2);
    static bool NAND(bool input1, bool input2);
};//close Boolean
#endif //Boolean_h