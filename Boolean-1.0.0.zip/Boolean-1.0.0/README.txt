Version 1.0.0

This boolean library is implemented specifically for Arduino's software control on boolean logic. 
Basic components include AND, OR, NOT, XOR, NOR, XNOR, and NAND gates as functions.

To use this library:
1) Import this ZIP library folder under the Sketch tab -> Include Library -> Add .ZIP Library
2) Write the header "#include <Boolean.h>" at the top
3) Write any of the above available functions in your sketch
   
   Note: Functions are static, so no object creation are necessary
         Write "Boolean::AND(input1,input2)" or "Boolean::NOT(input)" to call the functions
         "input1", "input2", and "input" parameters must be boolean values.
