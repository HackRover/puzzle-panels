---------------------------------- README for Button ----------------------------------
Date of creation: 4/3/23
Date last updated: 5/13/23

Last update:
Defined more robust comments and documentation

=== Purpose:
This document provides the functions to work as a toggle button or a depressed button. 
The button class also handles debouncing.

=== Materials required/included:
-Button.h file
-Button.cpp file
-keywords.txt
-ReadMe.txt
-Button

=== Terminologies
-Debouncing: when pressing or releasing the button, electrical signals and mechanical 
             buttons bounce high and low multiple times, leading to unexpected
			 results. Debouncing involves a small time buffer, so the change in state
			 is registered once, ensuring the correct result.
-Pull-up: Typically, a pull-up resistor is used in tandem with a button. Without a
          pull-up resistor, the button's state "floats" between HIGH (2.6 V - 5 V)
		  and LOW (0 V - 2.35 V), leading to unexpected results. A pull-up resistor
		  ensures that when the button is unpressed, the electrical signal is pulled
		  up to 5 V.

*Note: This library uses an internal pull-up resistor, which is 20 k - 50 kohms. When
       the button is unpressed, it is pulled HIGH. Conversely, when pressed, the 
	   button is considered LOW.

=== How to import custom Arduino libraries
1) Download desired custom Arduino library from Github
2) In your Arduino IDE, navigate Sketch tab -> Include Library -> Add .ZIP Library
3) Find your custom zipped folder and import it
4) Now, it should be imported as a custom library

=== How to use custom Arduino libraries
1) Navigate to Sketch tab -> Include Library -> scroll to the bottom of the 
   dropdown list to the section Contributed Libraries
2) Find desired custom library and insert it
3) Now, your custom header file should be included at the top
   eg. #include <Template.h>

=== References
Adapted from Michael Adams, the original author of this library
http://www.michael.net.nz