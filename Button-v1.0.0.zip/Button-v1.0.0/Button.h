/* ---------------------------------------- Button.h ----------------------------------------
 * Adapted from Michael Adams, the original author of this library
 * http://www.michael.net.nz
 * ------------------------------------------------------------------------------------------
 * Date of Creation: 4/3/23
 * Date last updated: 5/13/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes the user has the necessary materials to use the button properly
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides the functions to work as a toggle button or a depressed button.
 * The button class also handles debouncing.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation
 */

#ifndef BUTTON_H
#define BUTTON_H

#include "Arduino.h"

class Button
{
	public:
		//constructor
		Button(uint8_t newPin);

		//functions
		void begin();
		bool read();
		bool toggled();
		bool pressed();
		bool released();
		bool hasChanged();
		
		//constants
		const static bool PRESSED = LOW;
		const static bool RELEASED = HIGH;
	private:
		uint8_t  pin;
		uint16_t delay;
		bool     state;
		bool     hasChanged;
		uint32_t ignoreUntil;
};//close Button

#endif //BUTTON_H
