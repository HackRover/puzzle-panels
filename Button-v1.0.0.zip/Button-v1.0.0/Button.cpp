/* --------------------------------------- Button.cpp ---------------------------------------
 * Adapted from Michael Adams, the original author of this library
 * http://www.michael.net.nz
 * ------------------------------------------------------------------------------------------
 * Date of Creation: 4/3/23
 * Date last updated: 5/13/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes the user has the necessary materials to use the button properly
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides the functions to work as a toggle button or a depressed button.
 * The button class also handles debouncing.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation
 */

#ifndef BUTTON_CPP
#define BUTTON_CPP

#include "Button.h"
#include "Arduino.h"

//-------------------------------------- Constructors --------------------------------------
//One pin constructor
Button::Button(uint8_t newPin)
{  
	this -> pin(newPin),  
	this -> delay(500),  
	this -> state(HIGH),  
	this -> ignore_until(0),  
	this -> hasChanged(false)
}//close constructor



//--------------------------------------- Functions ---------------------------------------
//Initializes the pin with an internal 20k - 50k ohm pullup
void Button::begin()
{
	this -> pinMode(pin, INPUT_PULLUP);
}//close begin

//Read the state of the button
bool Button::read()
{
	//ignore pin changes until after this delay time
	if (ignoreUntil > millis())
	{
		// ignore any changes during this period
	}//close delay check 
	
	//pin has changed 
	else if(digitalRead(pin) != state)
	{
		ignoreUntil = millis() + delay;
		state = !state;
		hasChanged = true;
	}//close different state check
	
	return state;
}//close read

//Check has the button been toggled from on -> off, or vice versa
bool Button::toggled()
{
	read();

	return hasChanged();
}//close toggled

//Mostly internal, tells you if a button has changed after calling the read() function
bool Button::hasChanged()
{
	if(hasChanged == true)
	{
		hasChanged = false;

		return true;
	}//close has changed check

	return false;
}//close hasChanged

//Check has the button gone from off -> on
bool Button::pressed()
{
	if(read() == PRESSED && hasChanged() == true)
		return true;
	else
		return false;
}//close pressed

//Check has the button gone from on -> off
bool Button::released()
{
	if(read() == RELEASED && hasChanged() == true)
		return true;
	else
		return false;
}//close released

#endif //BUTTON_CPP