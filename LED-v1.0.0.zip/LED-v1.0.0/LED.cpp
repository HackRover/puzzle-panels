/* ---------------------------------------- LED.cpp ----------------------------------------
 * Adapted from proplantnom, the original author of this library
 * ------------------------------------------------------------------------------------------
 * Date of Creation: 4/5/23
 * Date last updated: 5/13/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes the user has the necessary materials to use the LED properly
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides the functions to turn on and off the LED as well as turn on. There 
 * is a function to handle blinking.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation. Blink should be updated to loop infinitely
 * as well; however, the mechanism to break out of the loop or the custom function to execute
 * within the loop is currently unknown.
 */

#ifndef LED_CPP
#define LED_CPP

#include "Arduino.h"
#include "LED.h"

//-------------------------------------- Constructors --------------------------------------
//One pin constructor
LED::LED(int _pin){
    this -> pin = _pin;
}//close constructor



//---------------------------------------- Methods ----------------------------------------
//Turn on LED
void LED::turnOn(){
    digitalWrite(this -> pin, HIGH);
}//close turnOn

//Turn off LED
void LED::turnOff(){
    digitalWrite(this -> pin, LOW);
}//close turnOff

//Blinks LED for set number of blinks and for a certain duration
void LED::blinkLED(unsigned long delayDuration, int loops){
    unsigned long lastBlink = 0;

    //no looping, simply turn on
    if(loops == 0){
        turnOn();
    }//close no looping check

    while(loops > 0){
        if(millis() - lastBlink > delayDuration){
            if(digitalRead(this -> pin) == HIGH){
                turnOff();
                loops--;
            }else{
                turnOn();
            }//close LED state check

            lastBlink = millis();
        }//close duration check
    }//close looping while

    turnOn();

    //To be implemented in the future
    //Currently unknown what will interrupt/break this cycle
    //if loops == -1, loop and blink indefinitely
}//close blinkLED

#endif //LED_CPP
