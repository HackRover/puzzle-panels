/* ----------------------------------------- LED.h -----------------------------------------
 * Adapted from proplantnom, the original author of this library
 * ------------------------------------------------------------------------------------------
 * Date of Creation: 4/5/23
 * Date last updated: 5/13/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes the user has the necessary materials to use the LED properly
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides the functions to turn on and off the LED as well as turn on. There 
 * is a function to handle blinking.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation. Blink should be updated to loop infinitely
 * as well; however, the mechanism to break out of the loop or the custom function to execute
 * within the loop is currently unknown.
 */

#ifndef LED_H
#define LED_H

#include "Arduino.h"

class LED{
    public:
        //constructor
        LED(int _pin);

        //methods
        void turnOn();
        void turnOff();
        void blinkLED(unsigned long delayDuration, int loops);

    private:
        int pin;
};

#endif //LED_H