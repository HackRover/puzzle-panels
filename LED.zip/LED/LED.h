#ifndef LED_H
#define LED_H

//Adapted from ProPlantnom

#include "Arduino.h"

class LED{
    public:
        //constructor
        LED(int _pin);

        //methods
        void turnOn();
        void turnOff();
        void blinkLED(unsigned long delayDuration, int loops);

    private:
        int pin;
};

#endif //LED_H