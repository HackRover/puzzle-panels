#ifndef LED_CPP
#define LED_CPP

//Adapted from ProPlantnom

#include "Arduino.h"
#include "LED.h"

//One pin constructor
LED::LED(int _pin){
    this -> pin = _pin;
}//close constructor

//Turn on LED
void LED::turnOn(){
    digitalWrite(this -> pin, HIGH);
}//close turnOn

//Turn off LED
void LED::turnOff(){
    digitalWrite(this -> pin, LOW);
}//close turnOff

//Blinks LED for set number of blinks and for a certain duration
void LED::blinkLED(unsigned long delayDuration, int loops){
    unsigned long lastBlink = 0;

    //no looping, simply turn on
    if(loops == 0){
        turnOn();
    }//close no looping check

    while(loops > 0){
        if(millis() - lastBlink > delayDuration){
            if(digitalRead(this -> pin) == HIGH){
                turnOff();
                loops--;
            }else{
                turnOn();
            }//close LED state check

            lastBlink = millis();
        }//close duration check
    }//close looping while

    turnOn();

    //To be implemented in the future
    //Currently unknown what will interrupt/break this cycle
    //if loops == -1, loop indefinitely
}//close blinkLED

#endif //LED_CPP
