-------------------------------- README for Boolean --------------------------------
Date of creation: 4/5/23
Date last updated: 5/12/23

Last update:
Defined more robust comments and documentation

=== Purpose:
This Boolean library provides basic boolean wrapper functions, especially useful 
for those unfamiliar with C++. No object creation required since functions are 
static.

=== Materials included:
-Boolean.h file
-Boolean.cpp file
-keywords.txt
-ReadMe.txt

=== How to import custom Arduino libraries
1) Download desired custom Arduino library from Github
2) In your Arduino IDE, navigate Sketch tab -> Include Library -> Add .ZIP Library
3) Find your custom zipped folder and import it
4) Now, it should be imported as a custom library

=== How to use custom Arduino libraries
1) Navigate to Sketch tab -> Include Library -> scroll to the bottom of the 
   dropdown list to the section Contributed Libraries
2) Find desired custom library and insert it
3) Now, your custom header file should be included at the top
   eg. #include <Template.h>