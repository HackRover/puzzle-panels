/* -------------------------------------- Boolean.cpp --------------------------------------
 * Date of Creation: 4/5/23
 * Date last updated: 5/12/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes inputs are boolean values
 * -Assumes user is familiar with boolean operations
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides basic boolean wrapper functions, especially useful for those 
 * unfamiliar with C++. No object creation required since functions are static.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation
 */

#ifndef BOOLEAN_CPP
#define BOOLEAN_CPP

#include "Boolean.h"
#include "Arduino.h"

//Returns the value of an OR operation
bool Boolean::OR(bool input1, bool input2)
{
    return input1 || input2;
}//close OR

//Returns the value of an AND operation
bool Boolean::AND(bool input1, bool input2)
{
    return input1 && input2;
}//close AND

//Returns the value of a NOT operation
bool Boolean::NOT(bool input)
{
    return !input;
}//close NOT

//Returns the value of an XOR operation
bool Boolean::XOR(bool input1, bool input2)
{
    return input1 ^ input2;
}//close XOR

//Returns the value of a NOR operation
bool Boolean::NOR(bool input1, bool input2)
{
    return !(input1 || input2);
}//close NOR

//Returns the value of an XNOR operation
bool Boolean::XNOR(bool input1, bool input2)
{
    return !(input1 ^ input2);
}//close XNOR

//Returns the value of a NAND operation
bool Boolean::NAND(bool input1, bool input2)
{
    return !(input1 && input2);
}//close NAND

#endif //BOOLEAN_CPP