/* --------------------------------------- Boolean.h ---------------------------------------
 * Date of Creation: 4/5/23
 * Date last updated: 5/12/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes inputs are boolean values
 * -Assumes user is familiar with boolean operations
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides basic boolean wrapper functions, especially useful for those 
 * unfamiliar with C++. No object creation required since functions are static.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation
 */
#ifndef BOOLEAN_H
#define BOOLEAN_H

#include "Arduino.h"

class Boolean
{
public:
    static bool OR(bool input1, bool input2);
    static bool AND(bool input1, bool input2);
    static bool NOT(bool input);
    static bool XOR(bool input1, bool input2);
    static bool NOR(bool input1, bool input2);
    static bool XNOR(bool input1, bool input2);
    static bool NAND(bool input1, bool input2);
};//close Boolean
#endif //BOOLEAN_H