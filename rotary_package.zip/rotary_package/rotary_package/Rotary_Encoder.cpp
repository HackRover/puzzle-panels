#ifndef Rotary_Encoder_cpp
#define Rotary_Encoder_cpp

//Adapted from proplantnom, author of this library

#import "Rotary_Encoder.h"
#include "Arduino.h"

//variables needed
//pin variable in order of CLD, DT, SW, 0, 0, 0, 0, 0, 0
//0 are currentStateCLK, lastStateCLK, counter, currentDir, lastButtonPress, buttonState
//int rotary[10] = 
//information for rotary



//Constructor
//
Rotary_Encoder::Rotary_Encoder(unsigned int clkpin, unsigned int dirpin, unsigned int swpin )
{
  this -> clockPin = clkpin; //0
  this -> directionPin = dirpin; //1
  this -> switchPin = swpin; //2
  this -> currentClockState = 0; //3
  this -> lastClockState = 0; //4
  this -> counter = 0; //5
  this -> currentDirection = 0; //6
  this -> lastButtonPressed = 0; //7
  this -> buttonState = 0; //8
}//close constructor


//Accessors
//
unsigned int Rotary_Encoder::getClockPin(){return this -> clockPin;}//close getClockPin

//
unsigned int Rotary_Encoder::getDirectionPin(){return this -> directionPin;}//close getDirectionPin

//
unsigned int Rotary_Encoder::getSwitchPin(){return this -> switchPin;}//close getSwitchPin

//
bool Rotary_Encoder::getCurrentClkState(){return this -> currentClockState;}//close getCurrentClkState

//
bool Rotary_Encoder::getLastClkState(){return this -> lastClockState;}//close getLastClkState

//
int Rotary_Encoder::getCounter(){return this -> counter;}//close getCounter

//
bool Rotary_Encoder::getCurrDir(){return this -> currentDirection;}//close getCurrDir

//
unsigned long Rotary_Encoder::getLastButtonPressed(){return this -> lastButtonPressed;}//close getLastButtonPressed

//
bool Rotary_Encoder::getButtonState(){return this -> buttonState;}//close getButtonState


//Mutators
//
void Rotary_Encoder::setCurrentClkState(bool currentState){this -> currentClockState = currentState;}//close setCurrentClkState

//
void Rotary_Encoder::setLastClkState(bool lastState){this -> lastClockState = lastState;}//close setLastClkState

//
void Rotary_Encoder::setCounter()
{
  //If encoder is rotating CW, then increment
  if((this -> getCurrentDirection()) == 1)
  {
    (this -> counter)++;
  }else
  {
    //if encoder is rotating CCW, then decrement
    (this -> counter)--;
  }//close direction check
}//close setCounter

//
void Rotary_Encoder::setCurrentDirection(bool direction){this -> currentDirection = direction;}//close setCurrentDirection

//
void Rotary_Encoder::setLastButtonPressed(unsigned long lastState){this -> lastButtonPressed = lastState;}//close setLastButtonPressed

//
void Rotary_Encoder::setButtonState(bool state){this -> buttonState = state;}//close setButtonState


//Functions
//sets up rotary module
void Rotary_Encoder::rotarySetup() 
{
  pinMode(this -> getClockPin, INPUT);
  pinMode(this -> getDirectionPin, INPUT);
  pinMode(this -> getSwitchPin, INPUT_PULLUP);
}//close rotarySetup

//updates the data for the rotary functions
void Rotary_Encoder::rotaryUpdate() 
{
  this.setCurrentClkState(digitalRead(this -> getClockPin()));

  //If last and current state of CLK are different, then pulse occurred
  //React to only 1 state change to avoid double count
  if((this -> getCurrentClkState() != this -> getLastClkState) && this -> getCurrentClkState == 1) 
  {
    //Wrong: different = CW, ++, 1; same = CCW, --, 0
    /*If the DT state is different than the CLK state, then
      the encoder is rotating CW so increment*/
    if(digitalRead(this -> getDirectionPin) != this -> getCurrentClkState) 
    {
      this -> setCurrentDirection(1);
    }else{
      // Encoder is rotating CCW so decrement
      this -> setCurrentDirection(0);
    }//close direction & clock state comparison

    this -> setCounter();
  }//close different clk state & current clk high check

  this -> setLastClkState(this -> getCurrentClkState);
  
  //updates button
  bool btnState = digitalRead(this -> getSwitchPin());

  //If we detect LOW signal, button is pressed
  if(btnState == LOW){
    /*if 50ms have passed since last LOW pulse, it means that the
    button has been pressed, released and pressed again*/
    if((millis() - this -> getLastButtonPressed()) > 50){
      this -> setButtonState(1);
    }else{
      this -> setButtonState(0);
    }//close buffer check

    //Remember last button press event
    this -> setLastButtonPressed(millis());
  }//close button pressed check
}//close rotaryUpdate

//
int Rotary_Encoder::rotaryDegree() 
{
  int degrees = ROTARY_PINS[7];

  while(degrees < 0){
    degrees = degrees + 20;
  }

  while (degrees > 19){
    degrees = degrees - 20;
  }
  
  degrees = degrees * 18;
  
  return(degrees);
}//close rotaryDegree

//Consider changing this into more accessible public function
//get total rotation
/*int rotary_rotation(int ROTARY_PINS[]) {
  return(ROTARY_PINS[5]);
}*/
#endif //Rotary_Encoder_cpp