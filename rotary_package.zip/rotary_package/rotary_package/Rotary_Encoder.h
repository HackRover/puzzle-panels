#ifndef Rotary_Encoder_h
#define Rotary_Encoder_h

#include "Arduino.h"

class Rotary_Encoder
{
    public:
    //Constructor
    Rotary_Encoder(unsigned int clkpin, unsigned int dirpin, unsigned int swpin);

    //Accessors
    unsigned int getClockPin();
    unsigned int getDirectionPin();
    unsigned int getSwitchPin();
    bool getCurrentClkState();
    bool getLastClkState();
    int getCounter();
    bool getCurrDir();
    unsigned long getLastButtonPressed();
    bool getButtonState();

    //Mutators
    void setCurrentClkState(bool currentState);
    void setLastClkState(bool lastState);
    void setCounter();
    void setCurrentDirection(bool direction);
    void setLastButtonPressed(unsigned long lastState);
    void setButtonState(bool state);

    //Functions
    void rotarySetup();
    void rotaryUpdate();
    int rotaryDegree();

    private:
    unsigned int clockPin;
    unsigned int directionPin;
    unsigned int switchPin;
    bool currentClockState;
    bool lastClockState;
    int counter;
    bool currentDirection; 
    unsigned long lastButtonPressed;
    bool buttonState;
};//close Rotary_Encoder
#endif //Rotary_Encoder_h