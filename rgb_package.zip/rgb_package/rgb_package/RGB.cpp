#ifndef RGB_cpp
#define RGB_cpp

/*
Adapted from proplantnom, the author of this library
*/

#import "RGB.h"
#include "Arduino.h"

//Constructor
//sets up a rgb light requires a array of the three pins in RGB order
//sets up baud rate for serial monitor
RGB::RGB(int rgbPins[3])
{
  this.redPin = rgbPins[0];
  this.greenPin = rgbPins[1];
  this.bluePin = rgbPins[2];

  Serial.begin(9600);
}//close RGB constructor


//Accessors
//returns the pin connected to red value
unsigned int RGB::getRedPin()
{
  return this.redPin;
}//close getRedPin

//returns the pin connected to green value
unsigned int RGB::getGreenPin()
{
  return this.greenPin;
}//close getGreenPin

//returns the pin connected to blue value
unsigned int RGB::getBluePin()
{
  return this.bluePin;
}//close getBluePin


//Functions
//initializes the pins for RGB LED in setup
void RGB::rgbSetup() {
  pinMode(this.getRedPin(), OUTPUT);
  pinMode(this.getGreenPin(), OUTPUT);
  pinMode(this.getBluePin(), OUTPUT);
}//close rgbSetup

//light up rgb light
void RGB::rgbOn(int redValue, int greenValue, int blueValue) {
  analogWrite(this.getRedPin(), 255 - redValue);
  analogWrite(this.getGreenPin(), 255 - greenValue);
  analogWrite(this.getBluePin(), 255 - blueValue);
}//close rgbOn

//turn off rgb light
void RGB::rgbOff() {
  analogWrite(this.getRedPin(), 0);
  analogWrite(this.getGreenPin(), 0);
  analogWrite(this.getBluePin(), 0);
}//close rgbOff

#endif //RGB_cpp