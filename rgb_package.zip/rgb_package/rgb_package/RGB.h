#ifndef RGB_h
#define RGB_h

/*
Adapted from proplantnom, the author of this library
*/

#include "Arduino.h"

class RGB{
    public:
    //Constructor
    RGB(int rgbPins[3]);

    //Accessors
    unsigned int getRedPin();
    unsigned int getGreenPin();
    unsigned int getBluePin();

    //Functions
    void rgbSetup();
    void rgbOn(int red_value, int green_value, int blue_value);
    void rgbOff();

    private:
    unsigned int redPin;
    unsigned int greenPin;
    unsigned int bluePin;
};//close RGB
#endif //RGB_h

