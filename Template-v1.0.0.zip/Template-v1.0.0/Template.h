/* REPLACE WHATEVER ARE IN THESE "" OR THE WORD "TEMPLATE" 
 * WITH YOUR CUSTOM FILE, FUNCTION, ETCETERA...
 * DELETE THESE CAPITALIZED COMMENT LINES WHEN FINISHED WITH CUSTOM FILE
 * PLEASE UPDATE THESE GUIDELINES AS NECESSARY
 * 
 * --------------------------------------- Template.h ---------------------------------------
 * ADJUST THESE HEADING DASHES AS NECESSARY
 * 
 * (Optional) Include original author(s) here if public Arduino library was used as reference
 * "Originally created by Long"
 * ------------------------------------------------------------------------------------------
 * Date of Creation: "5/11/23"
 * Date last updated: "5/12/23"
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions: (conditions for the code to work as expected)
 * -Assumes that creator understands the basics of C++
 * -Assumes reader can understand English proficient enough
 * -Assumes that first-time/returning HackRover member wants to create well-documented code
 * -Assumes the creator can use good judgement on what is consistent and readable code
 *    -It doesn't matter if camelCase, PascalCase, or snake_case is better; just
 *     stay consistent with personal preferences
 *    -Please use Allman or Kernighan & Ritchie bracket indentation styles; you will be 
 *     judged for using other styles
 *    -References and pointers can be place anywhere between the type and variable names
 *     eg: Template& cpy or Template &cpy or Template & cpy or Template&cpy or 
 *         Template    &    cpy......... It's the same with pointers
 *         Please choose one style and stick with it
 * -Assumes C++ files are written to be imported into Arduino libraries
 * ------------------------------------------------------------------------------------------
 * Postconditions: (how the code should work)
 * This document should provide the standard for readable code and comments. Additionally, 
 * since this template assumes that these files are written for Arduino libraries, some
 * code may be unnecessary. Adjust as needed
 * This template file gives examples of what could be defined in a header file. A message and 
 * recipient is stored in a linked list of nodes. Size is also tracked.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Comments, headers, and functions were defined
 */

#ifndef TEMPLATE_H //safeguard to avoid creating duplicate file names
#define TEMPLATE_H

//#include "Arduino.h" 
/* uncomment this before uploading
 * this #include "Arduino.h" does require a special environment (namely, PlatformIO on VSCode) 
 * to avoid getting the red error line. The special environment is not necessary in order for 
 * file to work as long as you understand Arduino's embedded C syntax without VSCode's red 
 * squiggle checker, but the environment is good for testing before uploading.
 */
#include <string>
#include <iostream>

using namespace std; //shorthand to avoid constantly rewriting it

class Template{
public:
    //forward reference to Node, so functions can call Node 
    struct Node;

    //Constructors
    Template();
    explicit Template(string msg, string name); 
    //explicit defines it as a constructor to avoid confusing it with casting
    Template(Template &cpy);

    //Destructor
    ~Template(); //required if anything is allocated to heap

    //Setters/Mutators
    void setMessage(const string msg, const string name);

    //Getters/Accessors
    string getMessage(const string name) const;
    int getSize() const;

    //Overloaded operators
    friend ostream& operator<<(ostream &out, const Template &other);
    bool operator==(const Template &other);
    Template& operator=(const Template &other);

    //Functions
    void sendMessage(string name);
    string findMessage(string name);

    //Utility/Helper Functions
    string recursivePrintMsg(Node *current, string name);

    //Structs
    struct Node{
        string message;
        string recipient;
        Node* next;
        Node* prev;
    };
private:
    //Member Variables
    Node* msgHead; //head for linked list of messages
    int size;

    //Private Function
    void setSize(const int num);
};//close Template

#endif //TEMPLATE_H