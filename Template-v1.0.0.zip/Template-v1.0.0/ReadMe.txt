DELETE THESE CAPITALIZED LINES AFTER FINISHING
FOLLOW THE HEADERS AS WRITTEN AND REPLACE WITH CUSTOM DIRECTIONS
UPDATE THE GUIDELINES AS NECESSARY

-------------------------------- README for Template --------------------------------
Date of creation: 5/11/23
Date last updated: 5/12/23

Last update:
Template.h, Template.cpp, keywords.txt, and ReadMe.txt are created.

=== Purpose:
This Template library demonstrates in the detail on how to create and define the 
structure of the C++ files to be imported into Arduinos. The comments and 
explanations should be clear enough where high schoolers experienced with STEM should 
be able to understand.

=== Materials required/included:
-At least one .h file
-At least one .cpp file
-keywords.txt
-ReadMe.txt

=== Terminologies
Insert technical terms here

=== How to create custom Arduino libraries
1) Implement all the files list in === Materials required
    a) The keywords.txt file is especially important as that allows the Arduino to
       recognize your custom objects and functions as reserved keywords.
2) Zip up your custom folder
3) In your Arduino IDE, navigate Sketch tab -> Include Library -> Add .ZIP Library
4) Find your custom zipped folder and import it
5) Now, it should be imported as a custom library

=== How to use custom Arduino libraries
1) Navigate to Sketch tab -> Include Library -> scroll to the bottom of the 
   dropdown list to the section Contributed Libraries
2) Find desired custom library and insert it
3) Now, your custom header file should be included at the top
   eg. #include <Template.h>

=== References
Include the original author here if public Arduino library is used as reference

Arduino documentation on creating custom libraries:
https://docs.arduino.cc/learn/contributions/arduino-creating-library-guide