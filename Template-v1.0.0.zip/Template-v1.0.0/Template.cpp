/* REPLACE WHATEVER ARE IN THESE "" OR THE WORD "TEMPLATE" 
 * WITH YOUR CUSTOM FILE, FUNCTION, ETCETERA...
 * DELETE THESE CAPITALIZED COMMENT LINES WHEN FINISHED WITH CUSTOM FILE
 * PLEASE UPDATE THESE GUIDELINES AS NECESSARY
 * 
 * -------------------------------------- Template.cpp --------------------------------------
 * ADJUST THESE HEADING DASHES AS NECESSARY
 * 
 * (Optional) Include original author(s) here if public Arduino library was used as reference
 * "Originally created by Long"
 * ------------------------------------------------------------------------------------------
 * Date of Creation: "5/11/23"
 * Date last updated: "5/12/23"
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions: (conditions for the code to work as expected)
 * -Assumes that creator understands the basics of C++
 * -Assumes reader can understand English proficient enough
 * -Assumes that first-time/returning HackRover member wants to create well-documented code
 * -Assumes the creator can use good judgement on what is consistent and readable code
 *    -It doesn't matter if camelCase, PascalCase, or snake_case is better; just
 *     stay consistent with personal preferences
 *    -Please use Allman or Kernighan & Ritchie bracket indentation styles; you will be 
 *     judged for using other styles
 *    -References and pointers can be place anywhere between the type and variable names
 *     eg: Template& cpy or Template &cpy or Template & cpy or Template&cpy or 
 *         Template    &    cpy......... It's the same with pointers
 *         Please choose one and stick with it
 * -Assumes C++ files are written to be imported into Arduino libraries
 * ------------------------------------------------------------------------------------------
 * Postconditions: (how the code should work)
 * This document should provide the standard for readable code and comments. Additionally, 
 * since this template assumes that these files are written for Arduino libraries, some
 * code may be unnecessary. Adjust as needed
 * This template file gives examples of what could be defined in a cpp file. A message and 
 * recipient is stored in a linked list of nodes. Size is also tracked.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Comments and functions were defined. Implementation are mostly commented.
 */

#ifndef TEMPLATE_CPP
#define TEMPLATE_CPP

#include "Template.h"

/* NOTE:
 * -INCLUDE SHORT DESCRIPTIONS FOR EACH CONSTRUCTOR/FUNCTION
 * -INCLUDE MORE COMMENTS AS NEEDED
 * -COMMENTS AFTER BRACKETS ARE AN OPTIONAL STYLE TO KEEP TRACK OF NESTED BRACKETS
 * -this KEYWORD IS ALSO AN OPTIONAL STYLE TO EXPLICITLY KEEP TRACK OF OBJECTS; NOT INCLUDING 
 *  this IMPLIES IT ANYWAYS
 */

//-------------------------------------- Constructors --------------------------------------
//Constructs default constructor if no message is passed in
Template::Template(){
    this -> msgHead = nullptr;
    this -> setSize(0);
}//close default constructor

//Constructs Template object that takes in string message for intended recipient
Template::Template(string msg, string name){
    this -> msgHead = new Node();

    this -> msgHead -> message = msg;
    this -> msgHead -> recipient = name;
    this -> msgHead -> next = nullptr;
    this -> msgHead -> prev = nullptr;
    this -> setSize(1);
}//close one arg constructor

//Constructs new Template and copies content
Template::Template(Template& cpy){
    //checks that the cpy Template exists and are not empty
    //parses through all nodes in cpy's linked list and inserts them into new Template
    //copies the size
}//close copy constructor



//---------------------------------------- Destructor ----------------------------------------
//Deletes content of Template before destructing the object
Template::~Template(){
    //checks that Template object is not empty
        //traverses to the end of the linked list
        //deletes node with message and remove pointers
        //make msgHead null
        //Template object can destruct safely
    //otherwise, just safely destruct
}//close destructor



//----------------------------------------- Setters -----------------------------------------
//Inserts new node and sets message for the intended recipient
void Template::setMessage(const string msg, const string name){
    //consider having some sorting algorithm, so Templates can be compared
    //traverses to intended spot of the linked list, if not empty
    //create new node and sets message of intended recipient
    //increase size
}//close setMessage

//Private function to set the size of the linked list
void Template::setSize(const int num){
    this -> size = num;
}//close setSize



//----------------------------------------- Getters -----------------------------------------
//Retrieves message for intended recipient
string Template::getMessage(string name) const{
    //checks that Template object is not empty
    //traverses through linked list
    //finds node with intended recipient
        //returns message
    //if not found, return empty message
}//close getMessage

//Retrieves size of the linked list
int Template::getSize() const{
    return this -> size;
}//close getSize



//----------------------------------- Overloaded Operators -----------------------------------
//Prints out contents of Template
/* Note that operator<< is not a part of Template class since it is a standard library operator
 * that's overloaded for printing purposes and friended to access private variables
 * Strangely, only iostreams are like this
 */
ostream& operator<<(ostream &out, const Template &other){
    //checks that Template object is not empty
    //traverse through each node in linked list via recursiveHelper functions
    //prints out its contents
}//close operator<<

//Compares Templates to see if they're equal
//Note that other operator types than iostreams are a part of Template class
bool Template::operator==(const Template &other){
    //checks that both Template objects are not empty
    //checks that both Template objects have the same size
    //if same size, parse through each node and compare messages and recipients
}//close operator==

//Assigns other Template object to this object
//Similar to copy constructor
Template& Template::operator=(const Template &other){
    //checks that other Template object is not empty
    //create new nodes and insert other Template object's nodes
    //insert size
}//close operator=



//---------------------------------------- Functions ----------------------------------------
//Send the message stored in Template to the intended recipient
void Template::sendMessage(string name){
    //finds the recipient via findMessage
    //send the message to recipient
}//close sendMessage

//Find the message stored in Template to the intended recipient and returns it
string Template::findMessage(string name){
    //traverses through linked list
    //find the message of the recipient
    //return the message
}//close findMessage



//------------------------------------ Utility Functions ------------------------------------
//Recursively traverses through linked list to find message for intended recipient
string Template::recursivePrintMsg(Node *current, string name){
    //while next node is not null
        //parse through linked list recursively
        //return message if intended recipient is found
}//close recursivePrintMsg

#endif //TEMPLATE_CPP