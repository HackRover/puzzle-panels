#ifndef RGB_CPP
#define RGB_CPP

/*
Adapted from proplantnom, the author of this library
*/

#include "RGB.h"
#include "Arduino.h"

//Constructors
//Constructs RGB object using individual pins
//Type of RGB determines operation
RGB::RGB(int _redPin, int _greenPin, int _bluePin, char type){
  this -> redPin = _redPin;
  this -> greenPin = _greenPin;
  this -> bluePin = _bluePin;
  this -> rgbType = type;
}//close individual pins constructor

//Constructs RGB object using array of pins
//Type of RGB determines operation
RGB::RGB(int pinArr[3], char type){
  this -> redPin = pinArr[0];
  this -> greenPin = pinArr[1];
  this -> bluePin = pinArr[2];
  this -> rgbType = type;
}//close pin array constructor


//Accessors
//returns the pin connected to red
unsigned int RGB::getRedPin(){
  return this -> redPin;
}//close getRedPin

//returns the pin connected to green
unsigned int RGB::getGreenPin(){
  return this -> greenPin;
}//close getGreenPin

//returns the pin connected to blue
unsigned int RGB::getBluePin(){
  return this -> bluePin;
}//close getBluePin

//return of RGB type of the LED (common-cathode or common-anode)
char RGB::getRGBType(){
  return this -> rgbType;
}//close getRGBType


//Functions
//initializes the pins for RGB LED in setup
void RGB::setup(){
  pinMode(this -> getRedPin(), OUTPUT);
  pinMode(this -> getGreenPin(), OUTPUT);
  pinMode(this -> getBluePin(), OUTPUT);
}//close rgbSetup

//light up all values to max value
void RGB::turnOn(){
  //if common-cathode
  if(this -> getRGBType() == 'c'){
    analogWrite(this -> getRedPin(), 255);
    analogWrite(this -> getGreenPin(), 255);
    analogWrite(this -> getBluePin(), 255);
  }//close cathode check

  //if common-anode
  if(this -> getRGBType() == 'a'){
    analogWrite(this -> getRedPin(), 0);
    analogWrite(this -> getGreenPin(), 0);
    analogWrite(this -> getBluePin(), 0);
  }//close anode check
}//close rgbOn

//turn off all rgb values
void RGB::turnOff(){
  //if common-cathode
  if(this -> getRGBType() == 'c'){
    analogWrite(this -> getRedPin(), 0);
    analogWrite(this -> getGreenPin(), 0);
    analogWrite(this -> getBluePin(), 0);
  }//close cathode check

  //if common-anode
  if(this -> getRGBType() == 'a'){
    analogWrite(this -> getRedPin(), 255);
    analogWrite(this -> getGreenPin(), 255);
    analogWrite(this -> getBluePin(), 255);
  }//close anode check
}//close rgbOff

//RGB glows red
void RGB::glowRed(){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getRedPin(), 255);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getRedPin(), 0);
   }//close anode check
}//close glowRed

//RGB glows green
void RGB::glowGreen(){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getGreenPin(), 255);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getGreenPin(), 0);
   }//close anode check
}//close glowGreen

//RGB glows blue
void RGB::glowBlue(){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getBluePin(), 255);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getBluePin(), 0);
   }//close anode check
}//close glowBlue

//RGB glows yellow
void RGB::glowYellow(){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getRedPin(), 255);
      analogWrite(this -> getGreenPin(), 255);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getRedPin(), 0);
      analogWrite(this -> getGreenPin(), 0);
   }//close anode check
}//close glowYellow

//RGB glows cyan
void RGB::glowCyan(){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getGreenPin(), 255);
      analogWrite(this -> getBluePin(), 255);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getGreenPin(), 0);
      analogWrite(this -> getBluePin(), 0);
   }//close anode check
}//close glowCyan

//RGB glows purple
void RGB::glowPurple(){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getRedPin(), 255);
      analogWrite(this -> getBluePin(), 255);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getRedPin(), 0);
      analogWrite(this -> getBluePin(), 0);
   }//close anode check
}//close glowPurple

//RGB glows a custom color
void RGB::glowCustom(int redValue, int greenValue, int blueValue){
   //if common-cathode
   if(this -> getRGBType() == 'c'){
      analogWrite(this -> getRedPin(), redValue);
      analogWrite(this -> getGreenPin(), greenValue);
      analogWrite(this -> getBluePin(), blueValue);
   }//close cathode check

   //if common-anode
   if(this -> getRGBType() == 'a'){
      analogWrite(this -> getRedPin(), 255 - redValue);
      analogWrite(this -> getGreenPin(), 255 - greenValue);
      analogWrite(this -> getBluePin(), 255 - blueValue);
   }//close anode check
}//close glowCustom

#endif //RGB_CPP