#ifndef RGB_H
#define RGB_H

/*
Adapted from proplantnom, the author of this library
*/

#include "Arduino.h"

class RGB{
    public:
    //Constructors
    RGB(int _redPin, int _greenPin, int _bluePin, char type);
    RGB(int pinArr[3], char type);

    //Accessors
    unsigned int getRedPin();
    unsigned int getGreenPin();
    unsigned int getBluePin();
    char getRGBType();

    //Functions
    void setup();
    void turnOn();
    void turnOff();
    void glowRed();
    void glowGreen();
    void glowBlue();
    void glowYellow();
    void glowCyan();
    void glowPurple();
    void glowCustom(int redValue, int greenValue, int blueValue);

    private:
    unsigned int redPin;
    unsigned int greenPin;
    unsigned int bluePin;
    char rgbType;
};//close RGB
#endif //RGB_H

