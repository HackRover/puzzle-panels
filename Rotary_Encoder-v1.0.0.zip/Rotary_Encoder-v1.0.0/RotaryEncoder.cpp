/* ------------------------------------ RotaryEncoder.cpp ------------------------------------
 * Adapted from proplantnom, the original author of this library
 * ------------------------------------------------------------------------------------------
 * Date of Creation: 4/5/23
 * Date last updated: 5/14/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes the user has the necessary materials to use the rotary encoder properly
 * -Assumes the user understands how the rotary encoder's clock timing works
 * -Assumes the user understands how the rotary encoder's switch works like a button
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides the functions for the direction, rotation, and switch for the
 * rotary encoder. Unlike the potentiometer, the rotary encoder has full 360 degree rotation
 * without limits.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation. rotary_rotation() needs to be redefined
 * and reimplemented in a public function getDegree().
 */

#ifndef ROTARY_ENCODER_CPP
#define ROTARY_ENCODER_CPP

#include "RotaryEncoder.h"
#include "Arduino.h"

//---------------------------------------- Constructors ----------------------------------------
//Assigns the clock, direction, and switch pins
RotaryEncoder::RotaryEncoder(unsigned int clkPin, unsigned int dirPin, unsigned int swPin)
{
  this -> clockPin = clkPin;
  this -> directionPin = dirPin;
  this -> switchPin = swPin;
  this -> currentClockState = 0;
  this -> lastClockState = 0;
  this -> counter = 0;
  this -> currentDirection = 0;
  this -> lastButtonPressed = 0;
  this -> buttonState = 0;
}//close constructor



//----------------------------------------- Accessors -----------------------------------------
//Returns the state of the clock pin
unsigned int RotaryEncoder::getClockPin() const{return this -> clockPin;}//close getClockPin

//Returns the state of the direction pin
unsigned int RotaryEncoder::getDirectionPin() const{return this -> directionPin;}//close getDirectionPin

//Returns the state of the switch pin
unsigned int RotaryEncoder::getSwitchPin() const{return this -> switchPin;}//close getSwitchPin

//Returns the state of the current clock
bool RotaryEncoder::getCurrClkState() const{return this -> currentClockState;}//close getCurrentClkState

//Returns the state of the previous clock state
bool RotaryEncoder::getLastClkState() const{return this -> lastClockState;}//close getLastClkState

//Returns the net counter in a certain direction
int RotaryEncoder::getCounter() const{return this -> counter;}//close getCounter

//Returns the state of the current direction
bool RotaryEncoder::getCurrDir() const{return this -> currentDirection;}//close getCurrDir

//Returns the state of the previous button state
unsigned long RotaryEncoder::getLastButtonPressed() const{return this -> lastButtonPressed;}//close getLastButtonPressed

//Returns the state the button is currently
bool RotaryEncoder::getButtonState() const{return this -> buttonState;}//close getButtonState



//------------------------------------------- Mutators -------------------------------------------
//Sets the current clock state
void RotaryEncoder::setCurrClkState(const bool currentState){this -> currentClockState = currentState;}//close setCurrentClkState

//Sets the last clock state
void RotaryEncoder::setLastClkState(const bool lastState){this -> lastClockState = lastState;}//close setLastClkState

//Sets the counter of net rotations in a certain direction
//CW increments and CCW decrements the counter
void RotaryEncoder::setCounter()
{
  //If encoder is rotating CW, then increment
  if((this -> getCurrDir()) == 1)
  {
    (this -> counter)++;
  }else
  {
    //if encoder is rotating CCW, then decrement
    (this -> counter)--;
  }//close direction check
}//close setCounter

//Sets the current direction
void RotaryEncoder::setCurrDir(const bool direction){this -> currentDirection = direction;}//close setCurrentDirection

//Sets the time of the button pressed last pressed
void RotaryEncoder::setLastButtonPressed(const unsigned long lastState){this -> lastButtonPressed = lastState;}//close setLastButtonPressed

//Sets the state of the button
void RotaryEncoder::setButtonState(const bool state){this -> buttonState = state;}//close setButtonState



//--------------------------------------- Functions ---------------------------------------
//Sets up rotary encoder
void RotaryEncoder::rotarySetup() 
{
  pinMode(this -> getClockPin(), INPUT);
  pinMode(this -> getDirectionPin(), INPUT);
  pinMode(this -> getSwitchPin(), INPUT_PULLUP);
}//close rotarySetup

//Updates the data for the rotary functions
void RotaryEncoder::rotaryUpdate() 
{
  this -> setCurrClkState(digitalRead(this -> getClockPin()));

  //If last and current state of CLK are different, then pulse occurred
  //React to only 1 state change to avoid double count
  if((this -> getCurrClkState() != this -> getLastClkState()) && this -> getCurrClkState() == 1) 
  {
    /*If the DT state is different than the CLK state, then
      the encoder is rotating CW so increment*/
    if(digitalRead(this -> getDirectionPin()) != this -> getCurrClkState()) 
    {
      this -> setCurrDir(1);
    }else{
      //Encoder is rotating CCW so decrement
      this -> setCurrDir(0);
    }//close direction & clock state comparison

    this -> setCounter();
  }//close different clk state & current clk high check

  this -> setLastClkState(this -> getCurrClkState());
  
  //updates button
  bool btnState = digitalRead(this -> getSwitchPin());

  //If we detect LOW signal, button is pressed
  if(btnState == LOW){
    /*if 50ms have passed since last LOW pulse, it means that the
    button has been pressed, released and pressed again*/
    if((millis() - this -> getLastButtonPressed()) > 50){
      this -> setButtonState(1);
    }else{
      this -> setButtonState(0);
    }//close buffer check

    //Remember last button press event
    this -> setLastButtonPressed(millis());
  }//close button pressed check
}//close rotaryUpdate

//Public function for getting net number of rotations in a certain direction
/*int RotaryEncoder::getDegree() 
{
  int degrees = ROTARY_PINS[7];

  while(degrees < 0){
    degrees = degrees + 20;
  }

  while (degrees > 19){
    degrees = degrees - 20;
  }
  
  degrees = degrees * 18;
  
  return(degrees);
}//close rotaryDegree*/

//Consider changing this into more accessible public function
//get total rotation
/*int rotary_rotation(int ROTARY_PINS[]) {
  return(ROTARY_PINS[5]);
}*/

#endif //ROTARY_ENCODER_CPP