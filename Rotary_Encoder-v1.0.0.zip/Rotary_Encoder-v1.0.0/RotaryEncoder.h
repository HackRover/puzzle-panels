/* ------------------------------------- RotaryEncoder.h -------------------------------------
 * Adapted from proplantnom, the original author of this library
 * ------------------------------------------------------------------------------------------
 * Date of Creation: 4/5/23
 * Date last updated: 5/14/23
 * ------------------------------------------------------------------------------------------
 * Preconditions/Assumptions:
 * -Assumes the user has the necessary materials to use the rotary encoder properly
 * -Assumes the user understands how the rotary encoder's clock timing works
 * -Assumes the user understands how the rotary encoder's switch works like a button
 * ------------------------------------------------------------------------------------------
 * Postconditions:
 * This document provides the functions for the direction, rotation, and switch for the
 * rotary encoder. Unlike the potentiometer, the rotary encoder has full 360 degree rotation
 * without limits.
 * ------------------------------------------------------------------------------------------
 * Last update:
 * Defined more robust comments and documentation. rotary_rotation() needs to be redefined
 * and reimplemented in a public function getDegree().
 */

#ifndef ROTARY_ENCODER_H
#define ROTARY_ENCODER_H

#include "Arduino.h"

class RotaryEncoder
{
    public:
    //Constructors
    RotaryEncoder(unsigned int clkPin, unsigned int dirPin, unsigned int swPin);

    //Accessors
    unsigned int getClockPin() const;
    unsigned int getDirectionPin() const;
    unsigned int getSwitchPin() const;
    bool getCurrClkState() const;
    bool getLastClkState() const;
    int getCounter() const;
    bool getCurrDir() const;
    unsigned long getLastButtonPressed() const;
    bool getButtonState() const;

    //Mutators
    void setCurrClkState(const bool currentState);
    void setLastClkState(const bool lastState);
    void setCounter();
    void setCurrDir(const bool direction);
    void setLastButtonPressed(const unsigned long lastState);
    void setButtonState(const bool state);

    //Functions
    void rotarySetup();
    void rotaryUpdate();
    //int getDegree();

    private:
    unsigned int clockPin;
    unsigned int directionPin;
    unsigned int switchPin;
    bool currentClockState;
    bool lastClockState;
    int counter;
    bool currentDirection; 
    unsigned long lastButtonPressed;
    bool buttonState;
};//close RotaryEncoder

#endif //ROTARY_ENCODER_H